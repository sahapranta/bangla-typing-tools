module.exports = {
  "extends": "standard"
};